
<div class="footer_fixed chreme-bg">
    <div class="main_wrap container">
        <ul>
            <li>
                <span class="grey-gradient-bg"><img src="/asset/img/coin-icon.png"></span>
                <p>Bank</p>
            </li>
            <li>
                <span class="grey-gradient-bg"><img src="/asset/img/updown-arrow-icon.png"></span>
                <p>Betting Profit &amp; Loss</p>
            </li>
            <li>
                <span class="grey-gradient-bg"><img src="/asset/img/history-icon.png"></span>
                <p>Betting History</p>
            </li>
            <li>
                <span class="grey-gradient-bg"><img src="/asset/img/user-icon.png"></span>
                <p>Profile</p>
            </li>
            <li>
                <span class="grey-gradient-bg"><img src="/asset/img/setting-icon.png"></span>
                <p>Change Status</p>
            </li>
        </ul>
    </div>
</div>


</div>

<script src="{{ asset('asset/js/jquery.js') }}" ></script>
<script src="{{ asset('asset/js/popper.min.js') }}" ></script>
<script src="{{ asset('asset/js/bootstrap.min.js') }}" ></script>
<script src="{{ asset('asset/js/jquery-ui.min.js') }}" ></script>
<script src="{{ asset('asset/js/jquery-ui.multidatespicker.js') }}" ></script>
<script src="{{ asset('asset/js/script.js') }}" ></script>


</body>

</html>
