<div class="rightblock-games white-bg">
    <div class="betslip-block">
        <a class="collape-link text-color-white blue-gradient-bg1" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
            Bet Slip <img src="{{ URL::to('asset/front/img/minus-icon.png') }} ">
        </a>
        <div class="collapse show" id="collapseExample">
            <div class="card card-body">
                Click on the odds to add selections to the betslip.
            </div>
        </div>
    </div>
</div>
